function student(imie, nazwisko, nr_indeksu, tablica_ocen){
  this.imie = imie;
  this.naziwsko = nazwisko;
  this.nr_indeksu = nr_indeksu;
  this.tablica_ocen = tablica_ocen;
}

student1 = new student("Mateusz", "Jagodzinski", 18318, [4, 3.5, 3.5, 4.5, 5, 3, 3.5]);
student2 = new student("Wieslaw", "Jarzabek", 2137, [5, 4, 3, 2, 3, 2, 5]);

console.log(student1.imie, student1.naziwsko, student1.nr_indeksu, "srednia ocen: ", eval(student1.tablica_ocen.join('+'))/student1.tablica_ocen.length);
