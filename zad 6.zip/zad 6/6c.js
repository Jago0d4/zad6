let name = "Mateusz";
let surname = "Jagodzinski";
let student_id = 18318;
let tablica_ocen = [4, 3.5, 3.5, 4.5, 5, 3, 3.5]
  const osoba = { name, surname, student_id, tablica_ocen};

console.log(osoba);
console.log("srednia ocen: ", eval(tablica_ocen.join('+'))/tablica_ocen.length);
