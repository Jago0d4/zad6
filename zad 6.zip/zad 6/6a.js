let person1 = new Object({
  name: 'Mateusz',
  surname: 'Jagodzinski',
  student_id: 18318,
});

console.log(person1);
