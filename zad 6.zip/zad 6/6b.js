
let name = "Mateusz";
let surname = "Jagodzinski";
let student_id = 18318;
  const osoba = { name, surname, student_id };

console.log(osoba);
